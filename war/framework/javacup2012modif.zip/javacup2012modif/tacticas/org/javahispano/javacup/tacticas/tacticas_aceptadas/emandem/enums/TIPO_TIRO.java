package org.javahispano.javacup.tacticas.tacticas_aceptadas.emandem.enums;

public enum TIPO_TIRO {
ALTO,
MEDIO,
BAJO
}
