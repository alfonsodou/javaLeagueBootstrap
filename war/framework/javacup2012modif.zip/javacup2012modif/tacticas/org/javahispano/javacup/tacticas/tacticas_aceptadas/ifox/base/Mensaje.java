/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javahispano.javacup.tacticas.tacticas_aceptadas.ifox.base;

/**
 *
 * @author Usuario
 */
public enum Mensaje {
    PASAR_BALON,
    RECIBIR_BALON,
    AYUDAR_ATACANTE,
}
