package org.javahispano.javacup.tacticas.tacticas_aceptadas.masia;

public enum Mentality{
	Normal,
	Offensive,
	Aggressive
}
