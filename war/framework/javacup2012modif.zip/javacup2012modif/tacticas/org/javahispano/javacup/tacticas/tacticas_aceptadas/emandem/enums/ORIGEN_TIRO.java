package org.javahispano.javacup.tacticas.tacticas_aceptadas.emandem.enums;

public enum ORIGEN_TIRO {
	PORTERO,
	DEFENSAS,
	MEDIO_CENTRAL_TRASERO,
	MEDIO_CENTRAL_DELANTERO,
	DELANTEROS
}
