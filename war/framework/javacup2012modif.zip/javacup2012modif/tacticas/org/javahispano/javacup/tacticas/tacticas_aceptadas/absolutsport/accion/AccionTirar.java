package org.javahispano.javacup.tacticas.tacticas_aceptadas.absolutsport.accion;

import org.javahispano.javacup.model.command.Command;

/**
 * Clase que implementa el interfaz Action y que representa la acci�n de tiro del jugador.
 * 
 * @author Christian Onwuzor Mart�n (chr -> airchris01@yahoo.es)
 */
public class AccionTirar implements Accion {

	private Command comando;
	private boolean dentroDeForzado;
	private double variacion;
	private boolean aPuertaVacia;
	private boolean tiroSeguro;
	
	
	public AccionTirar(Command comando, boolean dentroDeForzado, double variacion, boolean aPuertaVacia,
					   boolean tiroSeguro) {
		
		this.comando = comando;
		this.dentroDeForzado = dentroDeForzado;
		this.variacion = variacion;
		this.aPuertaVacia = aPuertaVacia;
		this.tiroSeguro = tiroSeguro;
	}

	public Command comando() {
		return comando;
	}
	
	public boolean dentroDeForzado() {
		return dentroDeForzado;
	}
	
	public double variacion() {
		return variacion;
	}
	
	public boolean aPuertaVacia() {
		return aPuertaVacia;
	}
	
	public boolean tiroSeguro() {
		return tiroSeguro;
	}

}
