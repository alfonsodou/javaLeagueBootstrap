package org.javahispano.javacup.tacticas.tacticas_aceptadas.emandem.enums;

public enum LADO_CANCHA {
SUPERIOR,
INFERIOR
}
