package org.javahispano.javacup.tacticas.tacticas_aceptadas.emandem.enums;

public enum CUADRANTE_CANCHA {
	CUADRANTE_1_SUP,
	CUADRANTE_2_SUP,
	CUADRANTE_3_SUP,
	CUADRANTE_4_SUP,
	CUADRANTE_1_INF,
	CUADRANTE_2_INF,
	CUADRANTE_3_INF,
	CUADRANTE_4_INF
}
