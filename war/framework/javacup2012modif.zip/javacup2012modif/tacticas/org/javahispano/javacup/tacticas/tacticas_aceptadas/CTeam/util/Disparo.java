package org.javahispano.javacup.tacticas.tacticas_aceptadas.CTeam.util;

public class Disparo {
	public final double anguloZ;

	public final double fuerza;

	public Disparo(double anguloZ, double fuerza) {
		this.fuerza = fuerza;
		this.anguloZ = anguloZ;
	}
}
