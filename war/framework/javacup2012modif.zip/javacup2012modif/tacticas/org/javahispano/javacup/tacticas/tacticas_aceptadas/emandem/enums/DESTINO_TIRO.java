package org.javahispano.javacup.tacticas.tacticas_aceptadas.emandem.enums;

public enum DESTINO_TIRO {
CORRER,
PASE,
TIRO_PORTERIA_SUP,
TIRO_PORTERIA_INF,
DESPEJE
}
