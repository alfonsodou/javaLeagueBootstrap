package org.javahispano.javacup.tacticas.tacticas_aceptadas.CTeam.tactica;

public interface IEstrategiaCT {
	public boolean ejecutarIteracion();
}
