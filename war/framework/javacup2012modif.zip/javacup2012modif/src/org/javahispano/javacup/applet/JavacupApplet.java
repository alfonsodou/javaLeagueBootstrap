package org.javahispano.javacup.applet;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.net.URL;

import org.javahispano.javacup.model.engine.PartidoGuardado;
import org.javahispano.javacup.render.VisorOpenGl;
import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
 
public class JavacupApplet extends Applet {
 
	Canvas display_parent;
 
	/** Thread which runs the main game loop */
	Thread gameThread;
 
	/** is the game loop running */
	boolean running = false;
 
	String  urlString; 
 
	public void startLWJGL() {
		gameThread = new Thread() {
			public void run() {
				running = true;
				try {
					Display.setParent(display_parent);
					Display.create();
					initGL();
				} catch (LWJGLException e) {
					e.printStackTrace();
					return;
				}
				gameLoop();
			}
		};
		gameThread.start();
	}
 
 
	/**
	 * Tell game loop to stop running, after which the LWJGL Display will 
	 * be destoryed. The main thread will wait for the Display.destroy().
	 */
	private void stopLWJGL() {
		running = false;
		try {
			gameThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
 
	public void start() {
 
	}
 
	public void stop() {
 
	}
 
	/**
	 * Applet Destroy method will remove the canvas, 
	 * before canvas is destroyed it will notify stopLWJGL()
	 * to stop the main game loop and to destroy the Display
	 */
	public void destroy() {
		remove(display_parent);
		super.destroy();
	}
 
	public void init() {
		urlString = getParameter("URL");
		setLayout(new BorderLayout());
		try {
			display_parent = new Canvas() {
				public final void addNotify() {
					super.addNotify();
					startLWJGL();
				}
				public final void removeNotify() {
					stopLWJGL();
					super.removeNotify();
				}
			};
			display_parent.setSize(getWidth(),getHeight());
			add(display_parent);
			display_parent.setFocusable(true);
			display_parent.requestFocus();
			display_parent.setIgnoreRepaint(true);
			setVisible(true);
		} catch (Exception e) {
			System.err.println(e);
			throw new RuntimeException("Unable to create display");
		}
	}
 
	protected void initGL() {
 
	}
 
	public void gameLoop() {


        try {
            //URL url = (URL) new URL("http://javaleagueprueba.appspot.com/jar/prueba.jvc");
        	System.out.println("URL: " + urlString);
            URL url = (URL) new URL(urlString);
            PartidoGuardado p = new PartidoGuardado(url);
//            setCursor(Cursor.getDefaultCursor());
            p.iterar();
            int sx = 800;
            int sy = 600;
                //setVisible(false);
//            	VisorOpenGl visorOpenGl = new VisorOpenGl(p, sx, sy, false, null); 
                VisorOpenGl.setVolumenAmbiente(0.5f);
                VisorOpenGl.setVolumenCancha(0.5f);
                VisorOpenGl.setMarcadorVisible(true);
                VisorOpenGl.setEntornoVisible(true);
                VisorOpenGl.setEstadioVisible(true);
                VisorOpenGl.setEscala(15);
                VisorOpenGl.setAutoescala(true);
                VisorOpenGl.setTexto(1);
                VisorOpenGl.setFPS(20);
                new VisorOpenGl(p, sx, sy, false, null, false);
        } catch (Exception e) {
            System.err.println(e);
			throw new RuntimeException("No se puede reproducir el partido!");
        }

		
		while(running) {
			Display.sync(60);
			Display.update();
		}
 
		Display.destroy();
	}
}